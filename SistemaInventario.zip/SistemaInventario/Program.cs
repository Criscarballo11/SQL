using System;

class Program
{
    static void Main(string[] args)
    {
        Inventario inventario = new Inventario();
        Cliente cliente = new Cliente("CL001", "Ana Torres", "ana.torres@email.com");

        bool salir = false;

        while (!salir)
        {
            Console.WriteLine("\n📋 Menú Principal");
            Console.WriteLine("1. Agregar Artículo");
            Console.WriteLine("2. Mostrar Inventario");
            Console.WriteLine("3. Buscar Artículo");
            Console.WriteLine("4. Modificar Artículo");
            Console.WriteLine("5. Mostrar Cliente");
            Console.WriteLine("6. Salir");
            Console.Write("Selecciona una opción: ");
            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    Console.Write("Código: ");
                    string codigo = Console.ReadLine();
                    Console.Write("Nombre: ");
                    string nombre = Console.ReadLine();
                    Console.Write("Precio: ");
                    decimal precio = decimal.Parse(Console.ReadLine());
                    Console.Write("Stock: ");
                    int stock = int.Parse(Console.ReadLine());

                    Articulo nuevo = new Articulo(codigo, nombre, precio, stock);
                    inventario.AgregarArticulo(nuevo);
                    break;

                case "2":
                    inventario.MostrarInventario();
                    break;

                case "3":
                    Console.Write("Ingrese el código del artículo: ");
                    string buscar = Console.ReadLine();
                    Articulo encontrado = inventario.BuscarArticulo(buscar);
                    if (encontrado != null)
                        encontrado.MostrarInfo();
                    else
                        Console.WriteLine("❌ Artículo no encontrado.");
                    break;

                case "4":
                    Console.Write("Código del artículo a modificar: ");
                    string codMod = Console.ReadLine();
                    Console.Write("Nuevo precio: ");
                    decimal nuevoPrecio = decimal.Parse(Console.ReadLine());
                    Console.Write("Nuevo stock: ");
                    int nuevoStock = int.Parse(Console.ReadLine());
                    inventario.ModificarArticulo(codMod, nuevoPrecio, nuevoStock);
                    break;

                case "5":
                    cliente.MostrarCliente();
                    break;

                case "6":
                    salir = true;
                    break;

                default:
                    Console.WriteLine("❌ Opción no válida.");
                    break;
            }
        }

        Console.WriteLine("👋 ¡Hasta luego!");
    }
}