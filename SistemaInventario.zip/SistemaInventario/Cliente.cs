using System;

public class Cliente
{
    public string IDCliente { get; set; }
    public string Nombre { get; set; }
    public string Correo { get; set; }

    public Cliente(string id, string nombre, string correo)
    {
        IDCliente = id;
        Nombre = nombre;
        Correo = correo;
    }

    public void MostrarCliente()
    {
        Console.WriteLine("\n👤 Cliente:");
        Console.WriteLine($"ID: {IDCliente}, Nombre: {Nombre}, Correo: {Correo}");
    }
}