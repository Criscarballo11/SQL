using System;

public class Inventario : Articulo
{
    private Articulo[] articulos = new Articulo[50];
    private int contador = 0;

    public Inventario() : base("", "", 0, 0) { }

    public void AgregarArticulo(Articulo nuevo)
    {
        if (contador < articulos.Length)
        {
            articulos[contador] = nuevo;
            contador++;
            Console.WriteLine("✅ Artículo agregado correctamente.");
        }
        else
        {
            Console.WriteLine("❌ Inventario lleno.");
        }
    }

    public void MostrarInventario()
    {
        Console.WriteLine("\n📦 Inventario:");
        for (int i = 0; i < contador; i++)
        {
            articulos[i].MostrarInfo();
        }
    }

    public Articulo BuscarArticulo(string codigo)
    {
        for (int i = 0; i < contador; i++)
        {
            if (articulos[i].Codigo == codigo)
                return articulos[i];
        }
        return null;
    }

    public void ModificarArticulo(string codigo, decimal nuevoPrecio, int nuevoStock)
    {
        Articulo art = BuscarArticulo(codigo);
        if (art != null)
        {
            art.Precio = nuevoPrecio;
            art.Stock = nuevoStock;
            Console.WriteLine("✅ Artículo modificado.");
        }
        else
        {
            Console.WriteLine("❌ Artículo no encontrado.");
        }
    }
}